<?php 
//aqui ira la cabecera de cada pagina
 ?>